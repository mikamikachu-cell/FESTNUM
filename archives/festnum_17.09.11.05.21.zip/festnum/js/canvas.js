console.log('site internet')

// function moveimage() {
//     document.getElementById('img1').style.left = "500px";
//     console.log('move')
// }


let canvas = document.querySelector('#canvas')
console.log(canvas)
let context = canvas.getContext('2d')

let positionX = 0;
let positionY = 0;

context.rect(positionX, positionY, 50, 50)
context.stroke()

let image = document.getElementById('sunset');

image.addEventListener('load', function () {
    context.drawImage(image, positionX, positionY, 50, 50);
}, false);

function move(e) {
    // alert(e.keyCode)
    if (e.keyCode == 39) {
        positionX += 5
    }
    if (e.keyCode == 38) {
        positionY -= 5
    }
    if (e.keyCode == 37) {
        positionX += -5
    }

    if (e.keyCode == 40) {
        positionY -= -5
    }

    canvas.width = canvas.width
    // context.rect(positionX, positionY, 50, 50)
    context.drawImage(image, positionX, positionY, 50, 50);
    context.stroke()
}

// context.strokeStyle = "red"

document.onkeydown = move;