console.log('site internet')

// function moveimage() {
//     document.getElementById('img1').style.left = "500px";
//     console.log('move')
// }


let canvas = document.querySelector('#canvas')
console.log(canvas)
let context = canvas.getContext('2d')

let positionx = 0;
let positiony = 0;

context.rect(positionx, positiony, 50, 50)
context.stroke()



function move(e) {
    // alert(e.keyCode)
    if (e.keyCode == 39) {
        positionx += 5
    }
    if (e.keyCode == 38) {
        positiony -= 5
    }
    if (e.keyCode == 37) {
        positionx += -5
    }

    if (e.keyCode == 40) {
        positiony -= -5
    }

    canvas.width = canvas.width
    context.rect(positionx, positiony, 50, 50)
    context.stroke()
}

// context.strokeStyle = "red"

document.onkeydown = move;