/* console.log("coucou"); */
let sprite = document.querySelector('#cigogne')
console.log('cigogne', sprite)
console.log('cigogne top', sprite.style.top)
console.log('cigogne left', sprite.style.left)

let positionX = 0
let positionY = 0

let accelX = 0
let accelY = 0

sprite.style.left = positionX + 'px'
sprite.style.top = positionY + 'px'

const CLAVIER_DROIT = 39
const CLAVIER_GAUCHE = 37
const CLAVIER_HAUT = 38
const CLAVIER_BAS = 40

function move(e) {

    if (e.keyCode == CLAVIER_DROIT) {
        console.log(accelX)
        console.log(positionX)
        accelX = accelX + 1
        positionX += accelX
        sprite.style.left = positionX + 'px'
        sprite.classList.remove('mirror')
    }
    if (e.keyCode == CLAVIER_HAUT) {
        positionY -= 5
        accelY = accelY + 1
        sprite.style.top = positionY + 'px'
        console.log(positionY, window.innerHeight);

    }
    if (e.keyCode == CLAVIER_GAUCHE) {
        positionX += -5
        accelX = accelX + 1
        positionX -= accelX
        sprite.style.left = positionX + 'px'
        sprite.classList.add('mirror')
    }

    if (e.keyCode == CLAVIER_BAS) {
        positionY -= -5
        accelY = accelY - 1
        sprite.style.top = positionY + 'px'
    }
}

function reset() {
    accelX = 0
}
document.onkeydown = move
document.onkeyup = reset